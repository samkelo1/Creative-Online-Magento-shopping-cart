<?php
class Devinc_Allcategories_Block_Allcategories extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
}