<?php
	class Devinc_Latestleaflet_Block_Latestleaflet extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
}