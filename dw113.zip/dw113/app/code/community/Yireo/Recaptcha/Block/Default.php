<?php
	/**
	 * Google Recaptcha for Magento 
		*
	 * @package     Yireo_Recaptcha
	 * @author      Yireo (http://www.yireo.com/)
	 * @copyright   Copyright (c) 2011 Yireo (http://www.yireo.com/)
	 * @license     Open Software License
	 */
	
	/**
	 * General helper
	 */
	class Yireo_Recaptcha_Block_Default extends Mage_Core_Block_Template
	{
		/*public function _toHtml()
			{
			$public_key = Mage::getStoreConfig('web/recaptcha/public_key');
			$private_key = Mage::getStoreConfig('web/recaptcha/private_key');
			
			if(empty($public_key) || empty($private_key)) {
            return null;
			}
			
			if(Mage::getSingleton('customer/session')->isLoggedIn() == true) {
            return null;
			}
			
			if(empty($theme)) $theme = 'clean';
			
			$theme = Mage::getStoreConfig('web/recaptcha/theme');
			$lang_code = preg_replace('/_([a-zA-Z0-9]+)$/', '', Mage::app()->getLocale()->getLocaleCode());
			
			if($theme == 'custom') {
            $this->setPublicKey($public_key);
            $this->setLangCode($lang_code);
            $this->setTemplate('recaptcha/custom.phtml');
            return parent::_toHtml();
			}
			
			require_once(dirname(__FILE__).DS.'..'.DS.'Lib'.DS.'recaptchalib.php');
			$html = null;
			$html .= "<script type=\"text/javascript\">\n"
            . " var RecaptchaOptions = {"
            . "     theme : '".$theme."',"
            . "     lang : '".Mage::app()->getLocale()->getLocaleCode()."'"
            . " };"
            . "</script>";
			$html .= recaptcha_get_html($public_key);
			
			return $html;
		}*/
		
		
		public function _toHtml()
		{
			$html='';
			$this->captcha = new Zend_Captcha_Image(array(
			'name' => 'are_you_human',
			'wordLen' => 6,
			'timeout' => 300,
			));
			$this->captcha->setSessionClass('Mage_Customer_Model_Session');
			$this->captcha->setImgDir(Mage::getBaseDir().'/media/captcha/');
			$this->captcha->setImgUrl('/media/captcha/');
			$font_path = Mage::getBaseDir()."/COOPBL.TTF";
			
			$this->captcha->setFont($font_path);
			$this->captcha->setFontSize(18);
			$this->captcha->setDotNoiseLevel(12);
			$this->captcha->setLineNoiseLevel(3);
			$this->captcha->setHeight(76);
			$this->captcha->setWidth(300);
			
			
			$id = $this->captcha->generate();
			
			$html.= '<div style="width:100%;float:left;">
			<div id="captcha-cont" style="width:100%;float:left;">'.$this->captcha->render().'</div>
			<div class="field" style="width:100%;float:left;">
			<div class="input-box"><input placeholder="Type the word above *" type="text" autocomplete="off" name="are_you_human[input]" id="are_you_human[input]" title="human" class="input-text required-entry"><input type="hidden" value="'.$id.'" name="are_you_human[id]"></div>
			<button type="button" id="caprefresh" class="dw-btn btn-blue" value="">
			<span>Refresh Image</span>
			</button>
			</div>
			</div>';
			$html.="
			<script type=text/javascript>
			function updateCaptcha(){
			var request = new Ajax.Request('".
			$this->getUrl('contacts/index/captcha')."',
			{
			method: 'post',
			onComplete: function(){},
			onSuccess: function(transport){
			
			if (transport && transport.responseText){
			try{
			response = eval('(' + transport.responseText + ')');
			}
			catch (e) {
			response = {};
			}
			}
			
			if(response.captcha){
			jQuery('#captcha-cont').html(response.captcha)
			return false;
			}
			},
			onFailure: function(){
			jQuery('#captcha-cont').html('Could not load')
			}
			
			}
			);
			
			}
			
			
			
			jQuery('#caprefresh').click(function(e){
			e.preventDefault();
			updateCaptcha()
			});
			
			</script>";
			return $html;
		}
	}
	
