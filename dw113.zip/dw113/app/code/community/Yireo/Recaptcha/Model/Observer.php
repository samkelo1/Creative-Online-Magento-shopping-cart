<?php
/**
 * Google Recaptcha for Magento 
 *
 * @package     Yireo_Recaptcha
 * @author      Yireo (http://www.yireo.com/)
 * @copyright   Copyright (c) 2011 Yireo (http://www.yireo.com/)
 * @license     Open Software License
 */

/**
 * Event observer
 */
class Yireo_Recaptcha_Model_Observer 
{
    public function beforeLoadLayout($observer)
    {
        if(Mage::getStoreConfig('web/recaptcha/overwrite_customer_form_register')) {
            $observer->getEvent()->getLayout()->getUpdate()->addHandle('recaptcha_customer_form_register');
        }

        if(Mage::getStoreConfig('web/recaptcha/overwrite_customer_form_login')) {
            $observer->getEvent()->getLayout()->getUpdate()->addHandle('recaptcha_customer_form_login');
        }

        if(Mage::getStoreConfig('web/recaptcha/overwrite_contacts_form')) {
            $observer->getEvent()->getLayout()->getUpdate()->addHandle('recaptcha_contacts_form');
        }

        if(Mage::getStoreConfig('web/recaptcha/overwrite_sendfriend_send')) {
            $observer->getEvent()->getLayout()->getUpdate()->addHandle('recaptcha_sendfriend_send');
        }

        if(Mage::getStoreConfig('web/recaptcha/overwrite_review_form')) {
            $observer->getEvent()->getLayout()->getUpdate()->addHandle('recaptcha_review_form');
        }
    }

    public function checkRecaptcha($observer)
    {
        /*$request = $observer->getEvent()->getControllerAction()->getRequest();
        
         $mod = $request->getModuleName().$request->getControllerName().$request->getActionName();
       // echo $mod;
        if($request->isPost()) {
            $post = $request->getPost();
            $recaptcha_found = false;
            if(is_array($post)) {
                foreach($post as $name => $value) {
                    if(preg_match('/^recaptcha_/', $name)) {
                        $recaptcha_found = true;
                        break;
                    }
                }
            }

            if($recaptcha_found) {

                require_once(dirname(__FILE__).DS.'..'.DS.'Lib'.DS.'recaptchalib.php');
                $private_key = Mage::getStoreConfig('web/recaptcha/private_key');
                $recaptcha = recaptcha_check_answer($private_key,
                    $_SERVER['REMOTE_ADDR'],
                    $request->getPost('recaptcha_challenge_field'),
                    $request->getPost('recaptcha_response_field')
                );

                if (!$recaptcha->is_valid) {

                    Mage::getSingleton('customer/session')->addError(Mage::helper('core')->__('Invalid captcha'));

                    $redirect_url = Mage::helper('core/http')->getHttpReferer();
                    if(empty($redirect_url)) {
                        $redirect_url = $recaptcha->getRequestString();
                    }

                    $response = Mage::app()->getFrontController()->getResponse();
                    $response->setRedirect($redirect_url);
                    $response->sendResponse();
                    exit;
                }
            }else{
                
               
                        
                if( $mod =='customeraccountcreatepost' || $mod =='contactsindexpost' ) {
                    Mage::getSingleton('customer/session')->addError(Mage::helper('core')->__('Invalid captcha'));

                    $redirect_url = Mage::helper('core/http')->getHttpReferer();
                    if(empty($redirect_url)) {
                        $redirect_url = $recaptcha->getRequestString();
                    }

                    $response = Mage::app()->getFrontController()->getResponse();
                    $response->setRedirect($redirect_url);
                    $response->sendResponse();
                    exit;
                }
            }
        }*/

        return $this;
    }
}
