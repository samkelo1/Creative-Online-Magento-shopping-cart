<?php
ini_set('display_errors', 1);
require_once 'app/Mage.php';
Mage::setIsDeveloperMode(true);
umask ( 0 );
$currentStore = Mage::app ()->getStore ()->getId ();
Mage::app ()->setCurrentStore ( Mage_Core_Model_App::ADMIN_STORE_ID );


$customers = Mage::getResourceModel ( 'customer/customer_collection' );
$customerIds = $customers->getAllIds ();
$write = Mage::getSingleton('core/resource')->getConnection('core_write');
$values = array();
foreach ( $customerIds as $customerId ) {
	$customer = Mage::getModel ( 'customer/customer' )->load ( $customerId );
	$data = array();
	$readresult=$write->query("SELECT * FROM mddsurvey_entry WHERE user_id = ".$customerId." and  question_id =-109");
    
        switch ($customer->getOptIn())
        {
            case '6':
                $opt = 'Email';
                break;
            case '4':
                $opt = 'Email & SMS';
                break;
            case '5':
                $opt = 'SMS';
                break;
            default:
            case '3':
                $opt = 'None';
                break;
        }
        while ($row = $readresult->fetch() ) {
            $data['answer'] = $row['value'];
            $data['created_at'] = $row['created_at'];
            $data['email'] =  $customer->getEmail();
            $data['first_name'] = $customer->getFirstname();
            $data['last_name'] = $customer->getLastname();
            $data['mobile'] = $customer->getMobileNo();
            $data['opt_in'] = $opt;
            $values[] = $data;
        }
        
        
        $fp = fopen('comp.csv', 'w');
                    
               foreach($values as $x)
               {
                   fputcsv($fp, $x,",",'"');
               }
           fclose($fp);
        
        
        
}
?>