<?php

$sc = new SoapClient('http://196.45.169.24:8000/ws/clntMDD_I_OnlineShopping.Flows:CreateAmendCDD?WSDL');

print($sc->__getLastResponse());
?>
