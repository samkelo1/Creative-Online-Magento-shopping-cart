<?php
	/**
	 * PriceCheck XML Generator
	 *
	 * Used to generate required data for XML export to PriceCheck
	 *
	 * @copyright Copyright 2009, PriceCheck (http://www.pricecheck.co.za)
	 * @author Kevin Tucker
	 */


	@set_time_limit(0);
	
    $shop_id=777;

	$required_ip = gethostbyname('admin.pricecheck.co.za');

	if (isset($_GET['debug']))
	{
		echo 'Required IP: '.$required_ip.' , Current IP: '.$_SERVER['REMOTE_ADDR']."\n";
	}

	if ($_SERVER['REMOTE_ADDR']!=$required_ip)
	{
		die('This is for PriceCheck only');
	}

	$_GET['page']=isset($_GET['page'])?$_GET['page']:1;
	
	
	
	
	
	
	/******************************* Configurable options (via _GET params) **********************************/
	$use_isbn = 0;
	if (isset($_GET['use_isbn']) && $_GET['use_isbn'])
	{
		$use_isbn = 1;
	}
	
	$use_shortdescription = 0;
	if (isset($_GET['use_shortdescription']) && $_GET['use_shortdescription'])
	{
		$use_shortdescription = 1;
	}
	
	$use_smallimage = 0;
	if (isset($_GET['use_smallimage']) && $_GET['use_smallimage'])
	{
		$use_smallimage = 1;
	}
	
	$show_categoryroot = 0;
	if (isset($_GET['show_categoryroot']) && $_GET['show_categoryroot'])
	{
		$show_categoryroot = 1;
	}
	
	
	
    require_once 'app/Mage.php';
    
    umask(0);
    Mage::app('default');
    
    /**** CONFIGURATION ****/
    $domain = Mage::getBaseUrl();

    $domain_parts=parse_url($domain);
    $domain=$domain_parts['scheme'].'://'.$domain_parts['host'];
    
    $media_path = "media/catalog/product";
    /***********************/
    
    //only let the error handler happen on fatal errors
	error_reporting(E_ERROR);
	
	ob_start();
    
	function utf8_compliant($str)
	{
	    if ( strlen($str) == 0 ) {
	        return TRUE;
	    }
	    // If even just the first character can be matched, when the /u
	    // modifier is used, then it's valid UTF-8. If the UTF-8 is somehow
	    // invalid, nothing at all will match, even if the string contains
	    // some valid sequences
	    return (preg_match('/^.{1}/us',$str,$ar) == 1);
	}

	function work_text($string)
	{
		$string=str_replace('�', '', $string);
		$string=str_replace('�', '', $string);
		$string=str_replace('�', '-', $string);
		$string=str_replace('�', '\'', $string);
		$string=str_replace('�', '"', $string);
		$string=str_replace(']]>', '', $string);
		$string=str_replace('<![CDATA[', '', $string);
		$string=str_replace('<![', '', $string);

		if (!utf8_compliant($string))
		{
			return utf8_encode(trim(preg_replace(array("/<br>/i", "/\n+/", "/\s+/", "/&reg;/", "/&trade;/"),array("\n", "\n", " ", "", ""),$string)));
		}
		else
		{
			return trim(preg_replace(array("/<br>/i", "/\n+/", "/\s+/", "/&reg;/", "/&trade;/"),array("\n", "\n", " ", "", ""),$string));
		}
	}

	/*
	 * Define the uniform node function
	 */
	function GenerateNode($data){
		global $shop_id;
		global $delivery_cost;
		global $currencies;

		$content = '';
		$content .= "\t" . '<Offer>' . "\n";
		$content .= "\t\t" . '<Category><![CDATA['.work_text($data['category']).']]></Category>' . "\n";
		$content .= "\t\t" . '<ProductName><![CDATA['.work_text($data['name']).']]></ProductName>' . "\n";
		$content .= "\t\t" . '<Manufacturer><![CDATA['.work_text($data['brand']).']]></Manufacturer>' . "\n";
		$content .= "\t\t" . '<ModelNumber><![CDATA['.work_text($data['model']).']]></ModelNumber>' . "\n";
		$content .= "\t\t" . '<UPC />' . "\n";
		$content .= "\t\t" . '<EAN />' . "\n";
		$content .= "\t\t" . '<ShopId>'.$shop_id.'</ShopId>' . "\n";
		$content .= "\t\t" . '<ShopSKU><![CDATA['.work_text($data['product_id']).']]></ShopSKU>' . "\n";
		$content .= "\t\t" . '<OfferName><![CDATA['.work_text($data['name']).']]></OfferName>' . "\n";
		$content .= "\t\t" . '<ProductLongDescription><![CDATA['.work_text($data['description']).']]></ProductLongDescription>' . "\n";
		$content .= "\t\t" . '<Price>'.work_text($data['price']).'</Price>' . "\n";
		if (isset($data['special_price']))
		{
			$content .= "\t\t" . '<SalePrice>'.work_text($data['special_price']).'</SalePrice>' . "\n";
		}
		$content .= "\t\t" . '<DeliveryCost>'.$delivery_cost.'</DeliveryCost>' . "\n";
		$content .= "\t\t" . '<VAT>0</VAT>' . "\n";
		$content .= "\t\t" . '<ProductURL><![CDATA['.work_text($data['product_url']).']]></ProductURL>' . "\n";
		$content .= "\t\t" . '<ImageURL><![CDATA['.work_text($data['image_url']).']]></ImageURL>' . "\n";
		$content .= "\t\t" . '<Notes />' . "\n";
		$content .= "\t\t" . '<StockAvailability>'.$data['stock_level'].'</StockAvailability>' . "\n";
		$content .= "\t" . '</Offer>' . "\n";
		return $content;
	} # end function

	//get default website
    $websites = Mage::getModel('core/website')->getCollection();
    $websites->load();
    
    foreach($websites as $_website) 
    {
    	$code=$_website->getCode();
	    if ($_website->is_default)
	    {
		    $default_website_id=$_website->getId();
	    }
    }

    //get products limited to default website
    $products = Mage::getModel('catalog/product')->getCollection();
    //var_dump($products);
    $products->addAttributeToFilter('status', 1);
    $products->addAttributeToFilter('visibility', 4);
    $products->addAttributeToSelect('*');
    $products->joinField('website',
                'catalog/product_website',
                'website_id',
                'product_id=entity_id',
                'website_id='.$default_website_id,
                'inner');
	$products->getSelect()->limitPage($_GET['page'],1000);
    $products->load();
    
    //var_dump($products);
    
    //var_dump();
    
	/*
	 * Send the XML content header
	 */
	header('Content-Type: text/xml');

	/*
	 * Echo the XML out tag
	 */
	
	echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
	echo '<Offers>' . "\n";
	
    
    foreach($products as $_product) {
    	$result=array();
    	
        $stock = $_product->getStockItem();
        $stock_item=$stock->toArray();

        if ($stock_item['is_in_stock'])
        {
	        $data = $_product->getData();
	
			$simplePricesTax = (Mage::helper('tax')->displayPriceIncludingTax() || Mage::helper('tax')->displayBothPrices());
			$_minimalPriceValue = $_product->getMinimalPrice();
			$_minimalPrice = Mage::helper('tax')->getPrice($_product, $_minimalPriceValue, $simplePricesTax);
		    $_price = Mage::helper('tax')->getPrice($_product, $_product->getPrice());
		    $_regularPrice = Mage::helper('tax')->getPrice($_product, $_product->getPrice(), $simplePricesTax);
		    $_finalPrice = Mage::helper('tax')->getPrice($_product, $_product->getFinalPrice());
		    $_finalPriceInclTax = Mage::helper('tax')->getPrice($_product, $_product->getFinalPrice(), true);
		    
			//get manufacturer
	        $attributes = $_product->getAttributes();
	        foreach ($attributes as $attribute) {
	        	if ($attribute->getAttributeCode()=='manufacturer')
	        	{
	                $manufacturer = $attribute->getFrontend()->getValue($_product);
	        	}
	        }
	    	
	        //category path
	    	$path = Mage::helper('catalog')->getBreadcrumbPath($_product->getCategory());
	    	Mage::helper('catalog/category');
	    	$categories = $_product->getCategoryIds();
	    	$category_path = Mage::getModel('catalog/category')->load($categories[0])->getPath();
	    	$all_category_ids=explode('/', $category_path);
	    	
	    	unset($all_category_ids[0]);
	    	
	    	if (!$show_categoryroot && is_array($all_category_ids)) //Axe root category
	    	{
				array_shift($all_category_ids);
	    	}
	    	
	    	$category_path='';
	    	
	    	foreach ($all_category_ids as $category_id) 
	    	{
	    		$category=Mage::getModel('catalog/category')->load($category_id);
	    		if (!empty($category_path))
	    		{
	    			$category_path.= ' > ';
	    		}
	    		$category_path.= $category->getName();
	    	}
	    	
	    	$result['category']=$category_path;
	    	$result['name']=$data['name'];
	    	$result['brand']=$manufacturer;
	    	
	    	if ($use_isbn && isset($data['isbn'])) //If option is set + data exists
	    	{
				$result['model']=$data['isbn'];
	    	}
	    	else
	    	{
				$result['model']=$data['sku'];
			}
	    	$result['product_id']=$data['entity_id'];
	    	
	    	if ($use_shortdescription && isset($data['short_description'])) //If option is set + data exists
	    	{
				$result['description']=$data['short_description'];
	    	}
	    	else
	    	{
				$result['description']=$data['description'];
			}
			
	    	$result['price']=$_regularPrice;
	    	if ($_finalPriceInclTax<$_regularPrice)
	    	{
	    		$result['special_price']=$_finalPriceInclTax;
	    	}
			$result['product_url']=$domain.'/'.$data['url_path'];
			
			
			if ($use_shortdescription && isset($data['small_image'])) //If option is set + data exists
	    	{
				$result['image_url']=$domain.'/'.$media_path . $data['small_image'];
	    	}
			else
			{
				$result['image_url']=$domain.'/'.$media_path . $data['image'];
			}
			
			$result['stock_level']=($stock_item['is_in_stock'])?'In Stock':'Out of Stock';;
	
			echo generateNode($result);
        }
    }
	echo '</Offers>' . "\n";
?> 
