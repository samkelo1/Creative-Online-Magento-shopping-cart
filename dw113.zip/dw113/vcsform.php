<form id="vcsform" method="POST" action="https://www.vcs.co.za/vvonline/ccform.asp">
<input type="hidden" name="p1" value="2666" />
<input type="hidden" name="p2" value="<?php echo time(); ?>" />
<input type="hidden" name="p3" value="Sale Goods" />
<input type="hidden" name="p4" value="<?php echo $_GET['c']; ?>" />
<input type="hidden" name="p5" value="ZAR" />
<!--<input type="hidden" name="p6" value="1">-->
<!--<input type="hidden" name="p7" value="g">-->
<!--<input type="hidden" name="p8" value="h">-->
<!--<input type="hidden" name="p9" value="i">-->
<!--<input type="hidden" name="p10" value="j">-->
<!--<input type="hidden" name="p11" value="k">-->
<input type="hidden" name="p12" value="Y" />
<input type="hidden" name="Budget" value="Y" />
<input type="hidden" name="NextOccurDate" value="o" />
<input type="hidden" name="CardholderEmail" value="<?php echo $_GET['e']; ?>" />
<!--<input type="hidden" name="Hash" value="q">-->
<!--<input type="hidden" name="m_1" value="z">-->
<!--<input type="hidden" name="m_2" value="z">-->
<!--<input type="hidden" name="m_3" value="z">-->
<!--<input type="hidden" name="m_4" value="z">-->
<!--<input type="hidden" name="m_5" value="z">-->
<!--<input type="hidden" name="m_6" value="z">-->
<!--<input type="hidden" name="m_7" value="z">-->
<!--<input type="hidden" name="m_8" value="z">-->
<!--<input type="hidden" name="m_9" value="z">-->
<!--<input type="hidden" name="m_10" value="z">-->
<input id="vcsbutton" type="submit" value="Pay by Credit Card" />
</form>
